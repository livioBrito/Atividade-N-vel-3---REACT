import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';

function AlbumDetails() {
  const { id } = useParams();
  const [album, setAlbum] = useState(null);
  const [photos, setPhotos] = useState([]);

  useEffect(() => {
    axios
      .get(`https://jsonplaceholder.typicode.com/albums/${id}`)
      .then((response) => {
        setAlbum(response.data);
      });

    axios
      .get(`https://jsonplaceholder.typicode.com/albums/${id}/photos`)
      .then((response) => {
        setPhotos(response.data.slice(0, 8));
      });
  }, [id]);

  if (!album) return null;

  return (
    <div>
      <Link to="/">Voltar</Link>
      <h1>{album.title}</h1>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 150px)',
          gridGap: '10px',
        }}
      >
               {photos.map((photo) => (
          <Link to={`/photo/${photo.id}`} key={photo.id}>
            <div
              style={{
                width: '150px',
                height: '150px',
                backgroundImage: `url(${photo.thumbnailUrl})`,
                backgroundSize: 'cover',
                borderRadius: '4px',
              }}
            ></div>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default AlbumDetails;

