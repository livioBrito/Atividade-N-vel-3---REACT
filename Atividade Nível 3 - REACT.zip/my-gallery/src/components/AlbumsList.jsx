import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

function AlbumsList() {
  const [albums, setAlbums] = useState([]);

  useEffect(() => {
    axios
      .get('https://jsonplaceholder.typicode.com/albums')
      .then((response) => {
        setAlbums(response.data);
      });
  }, []);

  return (
    <div>
      <h1>Galeria de fotos</h1>
      {albums.map((album) => (
        <Link to={`/album/${album.id}`} key={album.id}>
          <div
            style={{
              border: '1px solid black',
              padding: '10px',
              marginBottom: '10px',
            }}
          >
            {album.title}
          </div>
        </Link>
      ))}
    </div>
  );
}

export default AlbumsList;
