import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';

function PhotoDetails() {
  const { id } = useParams();
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    axios
      .get(`https://jsonplaceholder.typicode.com/photos/${id}`)
      .then((response) => {
        setPhoto(response.data);
      });
  }, [id]);

  if (!photo) return null;

  return (
    <div>
      <Link to={`/album/${photo.albumId}`}>Voltar</Link>
      <img
        src={photo.url}
        alt={photo.title}
        style={{ width: '600px', height: '600px' }}
      />
    </div>
  );
}

export default PhotoDetails;
