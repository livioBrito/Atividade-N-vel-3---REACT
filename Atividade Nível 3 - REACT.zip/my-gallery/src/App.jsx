import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AlbumsList from './components/AlbumsList';
import AlbumDetails from './components/AlbumDetails';
import PhotoDetails from './components/PhotoDetails';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AlbumsList />} />
        <Route path="/album/:id" element={<AlbumDetails />} />
        <Route path="/photo/:id" element={<PhotoDetails />} />
      </Routes>
    </Router>
  );
}

export default App;
